package baitap.bai1;

public class Main {
    public static void main(String[] args) {
        // Tạo khách hàng
        Customer customer = new Customer("123 Main St", "C001", "John Doe");
        
        // Tạo đơn hàng và thêm các mặt hàng
        Order order = new Order(customer);
        order.addLine(new OrderLine("Laptop", 1, 1000.0));
        order.addLine(new OrderLine("Mouse", 2, 25.0));

        // Tạo danh sách đơn hàng và thêm đơn hàng vào
        OrderList orderList = new OrderList();
        orderList.add(order);

        // In thông tin tổng số đơn hàng và tổng số tiền
        System.out.println("Số lượng đơn hàng: " + orderList.getCount());
        System.out.println("Tổng tiền của đơn hàng: " + order.getTotalAmount());
    }
}

