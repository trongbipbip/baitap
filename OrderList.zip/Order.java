package baitap.bai1;

import java.util.ArrayList;
import java.util.List;

public class Order {
    private Customer customer;
    private List<OrderLine> orderLines = new ArrayList<>();

    // Constructor
    public Order(Customer customer) {
        this.customer = customer;
    }

    // Add an OrderLine to the order
    public void addLine(OrderLine orderLine) {
        orderLines.add(orderLine);
    }

    // Remove an OrderLine from the order
    public void removeLine(OrderLine orderLine) {
        orderLines.remove(orderLine);
    }

    // Get total amount of the order
    public double getTotalAmount() {
        return orderLines.stream().mapToDouble(OrderLine::getTotal).sum();
    }

    // Getters and setters
    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public List<OrderLine> getOrderLines() {
        return orderLines;
    }
}

